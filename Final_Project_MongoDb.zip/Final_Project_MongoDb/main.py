from fastapi import FastAPI, HTTPException
from models import Incident, Analyst, InvestigationLog
from database import db

app = FastAPI(
    title="Cybersecurity Incident Tracking System"
)


@app.get("/")
def home():
    return {
        "message": "Cybersecurity Incident Tracking System Running"
    }


# INCIDENT APIs

@app.post("/incidents")
def create_incident(incident: Incident):

    db.incidents.insert_one(
        incident.model_dump()
    )

    return {
        "message": "Incident Created Successfully"
    }


@app.get("/incidents")
def get_incidents():

    incidents = []

    for incident in db.incidents.find({}, {"_id": 0}):
        incidents.append(incident)

    return incidents


@app.put("/incidents/{title}")
def update_incident(title: str, incident: Incident):

    result = db.incidents.update_one(
        {"title": title},
        {"$set": incident.model_dump()}
    )

    if result.matched_count == 0:
        raise HTTPException(
            status_code=404,
            detail="Incident not found"
        )

    return {
        "message": "Incident Updated Successfully"
    }


@app.delete("/incidents/{title}")
def delete_incident(title: str):

    result = db.incidents.delete_one(
        {"title": title}
    )

    if result.deleted_count == 0:
        raise HTTPException(
            status_code=404,
            detail="Incident not found"
        )

    return {
        "message": "Incident Deleted Successfully"
    }


# ANALYST APIs

@app.post("/analysts")
def create_analyst(analyst: Analyst):

    db.analysts.insert_one(
        analyst.model_dump()
    )

    return {
        "message": "Analyst Created Successfully"
    }


@app.get("/analysts")
def get_analysts():

    analysts = []

    for analyst in db.analysts.find({}, {"_id": 0}):
        analysts.append(analyst)

    return analysts


# LOG APIs

@app.post("/logs")
def create_log(log: InvestigationLog):

    db.logs.insert_one(
        log.model_dump()
    )

    return {
        "message": "Investigation Log Created Successfully"
    }


@app.get("/logs")
def get_logs():

    logs = []

    for log in db.logs.find({}, {"_id": 0}):
        logs.append(log)

    return logs

@app.get("/incidents/{title}")
def get_incident(title: str):

    incident = db.incidents.find_one(
        {"title": title},
        {"_id": 0}
    )

    if not incident:
        raise HTTPException(
            status_code=404,
            detail="Incident not found"
        )

    return incident


@app.get("/incident-logs/{title}")
def get_incident_logs(title: str):

    logs = []

    for log in db.logs.find(
        {"incident_title": title},
        {"_id": 0}
    ):
        logs.append(log)

    return logs