from pydantic import BaseModel

class Incident(BaseModel):
    title: str
    description: str
    severity: str
    status: str

class Analyst(BaseModel):
    name: str
    email: str
    specialization: str

class InvestigationLog(BaseModel):
    incident_title: str
    analyst_name: str
    log_message: str